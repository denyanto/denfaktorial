# My First Package

Ini merupakan paket pertama saya untuk menghitung faktorial dari suatu bilangan.
Misalnya Faktorial 5 maka nilainya sama dengan 5 * 4 * 3 * 2 * 1 =120.
