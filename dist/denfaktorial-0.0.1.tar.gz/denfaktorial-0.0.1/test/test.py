import denfaktorial

faktorial=denfaktorial(5)
print(faktorial)
